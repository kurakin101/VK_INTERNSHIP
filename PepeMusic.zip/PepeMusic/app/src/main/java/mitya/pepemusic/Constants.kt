package mitya.pepemusic

/**
 * Created by mitya on 13.10.17.
 */

const val EXTERNAL_STORAGE_PERMISSION_CODE = 1
const val PLAYBACK_CHANNEL_ID = "playback_channel"
const val PLAYBACK_NOTIFICATION_ID = 1
